import 'package:flutter/material.dart';

class VipClubScreen extends StatelessWidget {
  const VipClubScreen({super.key});

  @override
  Widget build(BuildContext context) {
    const deep = Color(0xFF240046);
    const purple = Color(0xFF7B2CBF);
    final benefits = <(IconData, String, String)>[
      (Icons.translate_rounded, 'Urdu live commentary', 'Fan-made translations or commentary where permission allows.'),
      (Icons.mic_rounded, 'Interview translations', 'Urdu summaries and translated highlights of interviews.'),
      (Icons.auto_awesome_rounded, 'Daily BTS moments', 'Curated moments, anniversaries and fan-made edits.'),
      (Icons.notifications_active_rounded, 'VIP updates', 'A dedicated place for premium updates and announcements.'),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('VIP ARMY Club 💜')),
      body: Container(
        decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFFFF8FF), Color(0xFFF0E3FF)])),
        child: ListView(padding: const EdgeInsets.all(18), children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF240046), Color(0xFF7B2CBF), Color(0xFFB5179E)]), borderRadius: BorderRadius.circular(28)),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(Icons.workspace_premium_rounded, color: Color(0xFFFFD166), size: 52),
              SizedBox(height: 12),
              Text('VIP ARMY CLUB', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 23, letterSpacing: 1.2)),
              SizedBox(height: 8),
              Text('A special corner for dedicated ARMY 💜', style: TextStyle(color: Colors.white70, fontSize: 14)),
              SizedBox(height: 18),
              Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                Text('Rs. 200', style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w900)),
                SizedBox(width: 8), Padding(padding: EdgeInsets.only(bottom: 5), child: Text('membership fee', style: TextStyle(color: Colors.white70))),
              ]),
            ]),
          ),
          const SizedBox(height: 22),
          const Text('VIP benefits', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: deep)),
          const SizedBox(height: 10),
          ...benefits.map((b) => Card(
            elevation: 0,
            color: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: Color(0xFFE8D8FF))),
            child: ListTile(
              leading: CircleAvatar(backgroundColor: const Color(0xFFF0E3FF), child: Icon(b.$1, color: purple)),
              title: Text(b.$2, style: const TextStyle(fontWeight: FontWeight.w800, color: deep)),
              subtitle: Text(b.$3),
            ),
          )),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: const Color(0xFFFFF4D6), borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFFFD166))),
            child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(Icons.info_outline_rounded, color: Color(0xFF8A5A00)),
              SizedBox(width: 10),
              Expanded(child: Text('Payments and real member verification are not connected yet. Please do not send money until an official, secure payment method is set up. VIP recordings or dubbing will only be shared where permission allows.', style: TextStyle(height: 1.4, color: Color(0xFF694600)))),
            ]),
          ),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: null,
            icon: const Icon(Icons.lock_rounded),
            label: const Text('Subscription activation coming soon'),
            style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
          ),
          const SizedBox(height: 8),
          const Text('This is the first UI version. Secure payment verification and private VIP content require a backend setup.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.black54)),
        ]),
      ),
    );
  }
}
