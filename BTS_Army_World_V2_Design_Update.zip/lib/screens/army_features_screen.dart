import 'package:flutter/material.dart';

class ArmyFeaturesScreen extends StatelessWidget {
  final String section;
  const ArmyFeaturesScreen({super.key, required this.section});

  @override
  Widget build(BuildContext context) {
    final isNews = section == 'Daily Updates';
    final isMembers = section == 'BTS Members';
    final isMusic = section == 'Music Zone';
    final isCommunity = section == 'ARMY Community';
    final items = isNews
        ? const [
            ('Today in BTS history', 'A daily space for anniversaries, milestones and memorable moments. Add verified links and dates before publishing.', Icons.calendar_month_rounded),
            ('Official announcements', 'Follow official BTS and member channels for reliable announcements and schedules.', Icons.campaign_rounded),
            ('Interviews & highlights', 'Share short summaries and links to authorized interviews, with your own commentary.', Icons.mic_rounded),
            ('ARMY birthday calendar', 'Celebrate member birthdays, album anniversaries and important fandom dates.', Icons.cake_rounded),
          ]
        : isMembers
            ? const [
                ('RM', 'Leader • Rapper • Artist', Icons.person_rounded),
                ('Jin', 'Vocalist • Performer', Icons.person_rounded),
                ('SUGA', 'Rapper • Producer', Icons.person_rounded),
                ('j-hope', 'Rapper • Dancer', Icons.person_rounded),
                ('Jimin', 'Vocalist • Dancer', Icons.person_rounded),
                ('V', 'Vocalist • Artist', Icons.person_rounded),
                ('Jung Kook', 'Vocalist • Performer', Icons.person_rounded),
              ]
            : isMusic
                ? const [
                    ('Albums & discography', 'Explore album details and official listening links.', Icons.album_rounded),
                    ('Songs & playlists', 'Build your favourite BTS song lists and open licensed music services.', Icons.queue_music_rounded),
                    ('Music videos', 'Use official video links rather than re-uploading copyrighted videos.', Icons.play_circle_rounded),
                  ]
                : const [
                    ('Share your ARMY story', 'A future community feed for fan stories, art and memories.', Icons.edit_note_rounded),
                    ('Fan art & edits', 'Post your own creations and credit artists when sharing their work.', Icons.palette_rounded),
                    ('Worldwide ARMY', 'Celebrate ARMY from Pakistan and around the world.', Icons.public_rounded),
                    ('Likes & comments', 'Community interactions will be enabled after account and database setup.', Icons.favorite_rounded),
                  ];

    return Scaffold(
      appBar: AppBar(title: Text(section)),
      body: Container(
        decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFFFF8FF), Color(0xFFF1E7FF)])),
        child: ListView(padding: const EdgeInsets.all(16), children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF9D4EDD), Color(0xFF5A189A), Color(0xFF240046)]), borderRadius: BorderRadius.circular(24)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Icon(Icons.favorite_rounded, color: Colors.white, size: 36),
              const SizedBox(height: 10),
              Text(section, style: const TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              Text(isNews ? 'Important moments and updates for ARMY 💜' : isMembers ? 'Seven members, one family.' : isMusic ? 'Albums, songs and official listening links.' : 'A welcoming space for ARMY worldwide.', style: const TextStyle(color: Colors.white70, height: 1.4)),
            ]),
          ),
          const SizedBox(height: 16),
          ...items.map((item) => Card(
            elevation: 0,
            color: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: Color(0xFFE8D8FF))),
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
              leading: CircleAvatar(backgroundColor: const Color(0xFFF0E3FF), child: Icon(item.$3, color: const Color(0xFF7B2CBF))),
              title: Text(item.$1, style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF240046))),
              subtitle: Padding(padding: const EdgeInsets.only(top: 5), child: Text(item.$2, style: const TextStyle(height: 1.35))),
              trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 15, color: Color(0xFF7B2CBF)),
              onTap: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Live content and community features need their data source connected.'))),
            ),
          )),
          if (isCommunity) const Padding(padding: EdgeInsets.only(top: 12), child: Text('Community posting, accounts and moderation will require a secure backend before launch.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.black54))),
          if (isNews) const Padding(padding: EdgeInsets.only(top: 12), child: Text('Updates shown here are starter sections, not live news yet. Connect a verified source before publishing current claims.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.black54))),
        ]),
      ),
    );
  }
}
