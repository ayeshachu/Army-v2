import 'package:flutter/material.dart';

class AppTheme {
  static final ThemeData light = ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.fromSeed(
      seedColor: const Color(0xFF7B2CBF),
      primary: const Color(0xFF7B2CBF),
      secondary: const Color(0xFFB5179E),
      surface: const Color(0xFFFFFBFF),
    ),
    scaffoldBackgroundColor: const Color(0xFFFFF8FF),
    appBarTheme: const AppBarTheme(
      centerTitle: true,
      backgroundColor: Color(0xFF5A189A),
      foregroundColor: Colors.white,
      elevation: 0,
    ),
  );
}
